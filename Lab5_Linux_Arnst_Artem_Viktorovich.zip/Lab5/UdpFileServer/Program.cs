using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
 
namespace UdpFileServer
{
    /// <summary>
    /// Отправитель файла по UDP (аналог UdpFileServer из методички).
    /// Сначала уходит сериализованный объект FileDetails (тип и размер),
    /// затем, через паузу, сам файл одним датаграммой.
    /// </summary>
    public class UdpFileServer
    {
        [Serializable]
        public class FileDetails
        {
            public string FILETYPE = "";
            public long FILESIZE = 0;
        }
 
        // Ограничение одной датаграммы: стандартный буфер UDP-сокета 8192 байта.
        private const int MaxDatagramSize = 8192;
        private const int RemotePort = 5002;
 
        private static readonly FileDetails fileDet = new FileDetails();
        private static IPAddress remoteIPAddress;
        private static readonly UdpClient sender = new UdpClient();
        private static IPEndPoint endPoint;
        private static FileStream fs;
 
        [STAThread]
        static void Main(string[] args)
        {
            Console.Title = "UDP файловый сервер (отправитель)";
            try
            {
                Console.Write("Введите удалённый IP-адрес (Enter = 127.0.0.1): ");
                string ip = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(ip)) ip = "127.0.0.1";
                remoteIPAddress = IPAddress.Parse(ip);
                endPoint = new IPEndPoint(remoteIPAddress, RemotePort);
 
                Console.Write("Введите путь к файлу и его имя: ");
                string path = (Console.ReadLine() ?? "").Trim('"', ' ');
                fs = new FileStream(path, FileMode.Open, FileAccess.Read);
 
                if (fs.Length > MaxDatagramSize)
                {
                    Console.WriteLine("Файл весит {0} байт, а одной датаграммой " +
                        "можно передать не больше {1} байт.", fs.Length, MaxDatagramSize);
                    sender.Close();
                    fs.Close();
                    return;
                }
 
                SendFileInfo();
                Console.WriteLine("Ожидание 2 секунды перед отправкой файла...");
                Thread.Sleep(2000);
                SendFile();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.WriteLine("Нажмите Enter для выхода.");
                Console.ReadLine();
            }
        }
 
        /// <summary>Сериализует FileDetails в XML и отправляет получателю.</summary>
        public static void SendFileInfo()
        {
            fileDet.FILETYPE = Path.GetExtension(fs.Name).TrimStart('.').ToLowerInvariant();
            fileDet.FILESIZE = fs.Length;
 
            XmlSerializer fileSerializer = new XmlSerializer(typeof(FileDetails));
            using (MemoryStream stream = new MemoryStream())
            {
                fileSerializer.Serialize(stream, fileDet);
                stream.Position = 0;
                byte[] bytes = stream.ToArray();
 
                Console.WriteLine("Отправка деталей файла: тип «{0}», размер {1} байт.",
                    fileDet.FILETYPE, fileDet.FILESIZE);
                sender.Send(bytes, bytes.Length, endPoint);
            }
        }
 
        /// <summary>Читает файл целиком и отправляет его одной дейтаграммой.</summary>
        private static void SendFile()
        {
            byte[] bytes = new byte[(int)fs.Length];
            fs.Read(bytes, 0, bytes.Length);
            Console.WriteLine("Отправка файла размером " + fs.Length + " байт...");
            try
            {
                sender.Send(bytes, bytes.Length, endPoint);
                Console.WriteLine("Файл успешно отправлен.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                fs.Close();
                sender.Close();
            }
        }
    }
}
