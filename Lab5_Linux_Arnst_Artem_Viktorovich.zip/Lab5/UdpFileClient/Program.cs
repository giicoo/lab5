using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Xml.Serialization;
 
namespace UdpFileClient
{
    /// <summary>
    /// Получатель файла по UDP (аналог UdpFileClient из методички).
    /// Слушает порт 5002, принимает FileDetails, затем сам файл,
    /// сохраняет его как temp.&lt;расширение&gt; и открывает связанной программой.
    /// </summary>
    public class UdpFileClient
    {
        [Serializable]
        public class FileDetails
        {
            public string FILETYPE = "";
            public long FILESIZE = 0;
        }
 
        private const int LocalPort = 5002;
 
        private static FileDetails fileDet;
        private static UdpClient receivingUdpClient;
        private static IPEndPoint remoteIpEndPoint = null;
        private static FileStream fs;
        private static byte[] receiveBytes = new byte[0];
 
        [STAThread]
        static void Main(string[] args)
        {
            Console.Title = "UDP файловый клиент (получатель)";
            try
            {
                receivingUdpClient = new UdpClient(LocalPort);
                Console.WriteLine("Получатель запущен на порту {0}. " +
                    "Ожидание отправителя...", LocalPort);
                GetFileDetails();
                ReceiveFile();
            }
            catch (SocketException ex)
            {
                Console.WriteLine("Не удалось занять порт {0}: {1}", LocalPort, ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.WriteLine("Нажмите Enter для выхода.");
                Console.ReadLine();
            }
        }
 
        /// <summary>Принимает и десериализует информацию о файле.</summary>
        private static void GetFileDetails()
        {
            Console.WriteLine("******* Ожидание информации о файле *******");
            receiveBytes = receivingUdpClient.Receive(ref remoteIpEndPoint);
            Console.WriteLine("Информация о файле получена от {0}.", remoteIpEndPoint);
 
            XmlSerializer fileSerializer = new XmlSerializer(typeof(FileDetails));
            using (MemoryStream stream = new MemoryStream())
            {
                stream.Write(receiveBytes, 0, receiveBytes.Length);
                stream.Position = 0;
                fileDet = (FileDetails)fileSerializer.Deserialize(stream);
            }
            Console.WriteLine("Получен файл типа .{0}, имеющий размер {1} байт.",
                fileDet.FILETYPE, fileDet.FILESIZE);
        }
 
        /// <summary>Принимает файл, сохраняет на диск и открывает его.</summary>
        public static void ReceiveFile()
        {
            Console.WriteLine("******* Ожидание файла *******");
            receiveBytes = receivingUdpClient.Receive(ref remoteIpEndPoint);
            Console.WriteLine("Файл получен, сохраняем...");
 
            // Не позволяем данным из сети задавать произвольный путь к файлу.
            string extension = fileDet.FILETYPE.Trim().TrimStart('.');
            if (extension.Length == 0 || extension.Length > 15 ||
                !System.Text.RegularExpressions.Regex.IsMatch(extension, "^[a-zA-Z0-9]+$"))
                throw new InvalidDataException("Недопустимое расширение файла");
            string fileName = "temp." + extension;
            fs = new FileStream(fileName, FileMode.Create,
                FileAccess.ReadWrite, FileShare.ReadWrite);
            fs.Write(receiveBytes, 0, receiveBytes.Length);
            fs.Flush();
            Console.WriteLine("Файл сохранён: {0} ({1} байт).",
                Path.GetFullPath(fileName), fs.Length);
 
            if (fs.Length != fileDet.FILESIZE)
                Console.WriteLine("Внимание: размер принятых данных не совпал с заявленным.");
            else
                Console.WriteLine("Размер совпадает с заявленным в заголовке.");
 
            fs.Close();
            receivingUdpClient.Close();
 
            // В Linux файл сохраняется без автоматического открытия.
            Console.WriteLine("Файл можно открыть вручную: " + Path.GetFullPath(fileName));
        }
    }
}
